import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
import joblib

# -----------------------------
# Create synthetic dataset
# -----------------------------
data = []

# Legitimate URLs (label = 0)
for _ in range(500):
    data.append([
        np.random.randint(20, 60),   # url length
        np.random.randint(1, 3),     # dots
        0,                            # @
        1,                            # https
        0,                            # ip
        np.random.randint(0, 2),     # hyphen
        1,                            # //
        0                             # label
    ])

# Phishing URLs (label = 1)
for _ in range(500):
    data.append([
        np.random.randint(70, 150),  # url length
        np.random.randint(3, 6),     # dots
        1,                            # @
        0,                            # https
        1,                            # ip
        np.random.randint(2, 6),     # hyphen
        np.random.randint(2, 5),     # //
        1                             # label
    ])

columns = [
    "url_length", "dots", "has_at",
    "https", "has_ip", "hyphen",
    "redirects", "label"
]

df = pd.DataFrame(data, columns=columns)

X = df.drop("label", axis=1)
y = df["label"]

# -----------------------------
# Train model
# -----------------------------
model = RandomForestClassifier(
    n_estimators=150,
    random_state=42
)

model.fit(X, y)

# -----------------------------
# Save model
# -----------------------------
joblib.dump(model, "phish_model.pkl")

print("✅ Model trained and saved as phish_model.pkl")
