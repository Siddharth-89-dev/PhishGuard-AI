from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import os

app = FastAPI()

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Serve static frontend
app.mount("/static", StaticFiles(directory="../frontend"), name="static")

# Home page
@app.get("/")
def serve_home():
    return FileResponse("../frontend/index.html")

# Product page
@app.get("/product")
def serve_product():
    return FileResponse("../frontend/product.html")

# Docs page
@app.get("/docs")
def serve_docs():
    return FileResponse("../frontend/docs.html")

# Contact page
@app.get("/contact")
def serve_contact():
    return FileResponse("../frontend/contact.html")
